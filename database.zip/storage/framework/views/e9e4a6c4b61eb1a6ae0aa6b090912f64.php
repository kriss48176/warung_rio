

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4 text-center">Status Pesanan Anda</h2>

    <?php if($statuses->isEmpty()): ?>
        <div class="text-center py-5">
            <p class="text-muted fs-5">Belum ada pesanan.</p>
            <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn btn-success">Lihat Menu</a>
        </div>
    <?php else: ?>
        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-4 shadow-sm border-0 rounded-4">
                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                    <span>Pesanan ID: <?php echo e($status->id); ?></span>
                    <span>Status: <strong><?php echo e(ucfirst($status->status)); ?></strong></span>
                </div>
                <div class="card-body">
                    <p><strong>Nama:</strong> <?php echo e($status->nama_pelanggan); ?></p>
                    <p><strong>Alamat:</strong> <?php echo e($status->alamat); ?></p>
                    <p><strong>No. HP:</strong> <?php echo e($status->no_hp); ?></p>
                    <p><strong>Metode Pembayaran:</strong> <?php echo e(ucfirst($status->metode_pembayaran)); ?></p>

                    <h6 class="mt-3">Daftar Menu:</h6>
                    <ul class="list-group mb-3">
                        <?php $__currentLoopData = $status->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e($item['nama_menu']); ?> (<?php echo e($item['jumlah']); ?>)
                                <span>Rp <?php echo e(number_format($item['total_harga'],0,',','.')); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between fw-bold">
                            Total
                            <span>Rp <?php echo e(number_format($status->total_harga,0,',','.')); ?></span>
                        </li>
                    </ul>
                    <p class="text-muted"><small>Dipesan pada: <?php echo e($status->created_at->format('d M Y, H:i')); ?></small></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/pelanggan/status.blade.php ENDPATH**/ ?>