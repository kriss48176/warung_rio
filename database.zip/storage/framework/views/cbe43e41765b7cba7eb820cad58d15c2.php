

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4 text-center">Keranjang Belanja</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($items->isEmpty()): ?>
        <div class="text-center py-5">
            <p class="text-muted fs-5">Keranjang Anda kosong. Silakan pilih menu terlebih dahulu.</p>
            <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn btn-success">Lihat Menu</a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table align-middle text-center">
                <thead class="table-success">
                    <tr>
                        <th>Menu</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $grandTotal = 0; ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $grandTotal += $item->total_harga; ?>
                    <tr>
                        <td class="text-start d-flex align-items-center">
                            <img src="<?php echo e(asset('assets/gambar/'.$item->menu->gambar)); ?>" alt="<?php echo e($item->menu->nama_menu); ?>" style="width: 80px; height: 60px; object-fit: cover; border-radius:6px; margin-right:10px;">
                            <span><?php echo e($item->menu->nama_menu); ?></span>
                        </td>
                        <td>Rp <?php echo e(number_format($item->harga,0,',','.')); ?></td>
                        <td>
                            <form action="<?php echo e(route('keranjang.update', $item->id)); ?>" method="POST" class="d-flex justify-content-center align-items-center">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="number" name="jumlah" value="<?php echo e($item->jumlah); ?>" min="1" class="form-control" style="width:70px;">
                                <button type="submit" class="btn btn-sm btn-primary ms-2">Update</button>
                            </form>
                        </td>
                        <td>Rp <?php echo e(number_format($item->total_harga,0,',','.')); ?></td>
                        <td>
                            <form action="<?php echo e(route('keranjang.destroy', $item->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fa fa-trash"></i> Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="fw-bold">
                        <td colspan="3" class="text-end">Grand Total</td>
                        <td colspan="2">Rp <?php echo e(number_format($grandTotal,0,',','.')); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-end mt-4">
            <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-success btn-lg">
                <i class="fa fa-credit-card me-2"></i> Checkout
            </a>
        </div>
    <?php endif; ?>
</div>


<style>
    table th, table td {
        vertical-align: middle;
    }

    table img {
        transition: transform 0.3s;
    }

    table img:hover {
        transform: scale(1.05);
    }

    input[type=number] {
        text-align: center;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/pelanggan/keranjang.blade.php ENDPATH**/ ?>