

<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <h3>Data Pesanan</h3>
    <hr>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Pelanggan</th>
                <th>No HP</th>
                <th>Total Harga</th>
                <th>Status</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->id_pesanan); ?></td>
                <td><?php echo e($p->nama_pelanggan); ?></td>
                <td><?php echo e($p->no_hp); ?></td>
                <td>Rp <?php echo e(number_format($p->total_harga,0,',','.')); ?></td>
                <td>
                    <span class="badge bg-info"><?php echo e($p->status_pesanan); ?></span>
                </td>
                <td><?php echo e($p->tanggal_pesan); ?></td>

                <td>
                    <a href="<?php echo e(url('/admin/pesanan/'.$p->id_pesanan)); ?>" class="btn btn-sm btn-primary">
                        Detail
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/admin/pesanan/index.blade.php ENDPATH**/ ?>