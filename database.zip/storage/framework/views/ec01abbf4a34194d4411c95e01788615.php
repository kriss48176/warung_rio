<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            background: #f7f7f7;
        }
        .sidebar {
            width: 250px;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        .sidebar .admin-header {
            background: rgba(255,255,255,0.1);
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        .sidebar .admin-header .admin-icon {
            font-size: 3rem;
            color: #fff;
            margin-bottom: 10px;
        }
        .sidebar .admin-header h4 {
            color: #fff;
            margin: 0;
            font-weight: 600;
        }
        .sidebar a {
            color: #fff;
            display: block;
            padding: 15px 20px;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            background: none;
        }
        .sidebar a:hover {
            background: rgba(255,255,255,0.2);
            transform: translateX(5px);
        }
        .sidebar a i {
            margin-right: 10px;
            width: 20px;
        }
        .sidebar .logout {
            position: absolute;
            bottom: 20px;
            width: 100%;
            border-top: 1px solid rgba(255,255,255,0.2);
        }
        .sidebar .logout a {
            color: #ff6b6b;
        }
        .sidebar .logout a:hover {
            background: rgba(255, 107, 107, 0.2);
            color: #fff;
        }
        .content {
            margin-left: 250px;
            padding: 30px;
        }
        .sidebar .menu-section {
            padding: 10px 0;
        }
        .sidebar .menu-section h6 {
            color: rgba(255,255,255,0.7);
            text-transform: uppercase;
            font-size: 0.8rem;
            font-weight: 600;
            padding: 0 20px;
            margin: 10px 0 5px 0;
        }
    </style>
</head>
<body>

    
    <div class="sidebar position-fixed">
        <div class="admin-header">
            <div class="admin-icon">
                <i class="fas fa-user-shield"></i>
            </div>
            <h4>Rumah Makan Rio </h4>
        </div>

        <div class="menu-section">
            <h6>Dashboard</h6>
            <a href="<?php echo e(url('/admin')); ?>">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
        </div>

        <div class="menu-section">
            <h6>Management</h6>
            <a href="<?php echo e(url('/admin/kategori')); ?>">
                <i class="fas fa-tags"></i> Kelola Kategori
            </a>
            <a href="<?php echo e(url('/admin/menu')); ?>">
                <i class="fas fa-utensils"></i> Kelola Menu
            </a>
            <a href="<?php echo e(url('/admin/pesanan')); ?>">
                <i class="fas fa-shopping-cart"></i> Kelola Pesanan
            </a>
        </div>

        <div class="logout">
            <form action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: inline;">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background: none; border: none; color: #ff6b6b; padding: 15px 20px; text-decoration: none; transition: all 0.3s ease; border: none; background: none; width: 100%; text-align: left;" onmouseover="this.style.background='rgba(255, 107, 107, 0.2)'; this.style.color='#fff'" onmouseout="this.style.background='none'; this.style.color='#ff6b6b'">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </form>
        </div>
    </div>

    
    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH C:\Users\acer\warung_rio1\resources\views/layouts/admin.blade.php ENDPATH**/ ?>