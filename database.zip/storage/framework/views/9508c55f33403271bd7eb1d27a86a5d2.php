

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4 text-center">Menu Rumah Makan Rio 1</h2>

    
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm border-0 rounded-4">
                
                <img src="<?php echo e(asset('assets/gambar/'.$menu->gambar)); ?>" 
                     class="card-img-top rounded-top-4" 
                     alt="<?php echo e($menu->nama_menu); ?>" 
                     style="height: 200px; object-fit: cover;">

                <div class="card-body d-flex flex-column">
                    
                    <h5 class="card-title"><?php echo e($menu->nama_menu); ?></h5>
                    <p class="text-muted mb-2" style="font-size: 0.9rem;">
                        Kategori: <?php echo e($menu->kategori->nama_kategori ?? 'Umum'); ?>

                    </p>

                    
                    <p class="card-text mb-3" style="flex-grow:1;">
                        <?php echo e(Str::limit($menu->deskripsi, 80, '...')); ?>

                    </p>

                    
                    <h6 class="mb-3 fw-bold text-primary">Rp <?php echo e(number_format($menu->harga,0,',','.')); ?></h6>

                    
                    <form action="<?php echo e(route('keranjang.add', $menu->id_menu)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success w-100">
                            Tambah ke Keranjang
                        </button>
                    </form>

                    
                    <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-primary w-100 mt-2">
                        Pesan
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center">
            <p class="text-muted">Menu sedang kosong, silakan cek kembali nanti.</p>
        </div>
        <?php endif; ?>
    </div>
</div>


<style>
.card:hover {
    transform: translateY(-5px);
    transition: 0.3s;
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/pelanggan/menu_pelanggan.blade.php ENDPATH**/ ?>