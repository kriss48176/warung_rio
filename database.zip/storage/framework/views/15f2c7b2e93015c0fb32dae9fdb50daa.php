

<?php $__env->startSection('content'); ?>

<div class="container mt-4">

    <h3>Detail Pesanan #<?php echo e($pesanan->id_pesanan); ?></h3>
    <hr>

    <h5>Data Pelanggan</h5>
    <table class="table">
        <tr>
            <th>Nama</th>
            <td><?php echo e($pesanan->nama_pelanggan); ?></td>
        </tr>
        <tr>
            <th>No HP</th>
            <td><?php echo e($pesanan->no_hp); ?></td>
        </tr>
        <tr>
            <th>Alamat</th>
            <td><?php echo e($pesanan->alamat); ?></td>
        </tr>
    </table>

    <h5>Detail Pesanan</h5>

    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>Menu</th>
                <th>Harga</th>
                <th>Jumlah</th>
                <th>Subtotal</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $pesanan->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d->menu->nama_menu); ?></td>
                <td>Rp <?php echo e(number_format($d->menu->harga, 0, ',', '.')); ?></td>
                <td><?php echo e($d->jumlah); ?></td>
                <td>Rp <?php echo e(number_format($d->subtotal, 0, ',', '.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h4>Total: Rp <?php echo e(number_format($pesanan->total_harga,0,',','.')); ?></h4>

    <hr>

    <h5>Ubah Status Pesanan</h5>

    <form action="<?php echo e(url('/admin/pesanan/'.$pesanan->id_pesanan)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <select name="status_pesanan" class="form-control" style="width: 200px;">
            <option value="Menunggu" <?php echo e($pesanan->status_pesanan=='Menunggu'?'selected':''); ?>>Menunggu</option>
            <option value="Diproses" <?php echo e($pesanan->status_pesanan=='Diproses'?'selected':''); ?>>Diproses</option>
            <option value="Diantar" <?php echo e($pesanan->status_pesanan=='Diantar'?'selected':''); ?>>Diantar</option>
            <option value="Selesai" <?php echo e($pesanan->status_pesanan=='Selesai'?'selected':''); ?>>Selesai</option>
        </select>

        <button type="submit" class="btn btn-success mt-2">Update Status</button>
    </form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/admin/pesanan/show.blade.php ENDPATH**/ ?>