<?php $__env->startSection('content'); ?>

<div class="container-fluid px-0" style="background: linear-gradient(135deg, #f8fafb 0%, #f0f3f7 100%); min-height: 100vh;">
    
    
    <div class="bg-white shadow-sm sticky-top" style="top: 70px; z-index: 1020;">
        <div class="px-3 pt-3 pb-2">
            <h4 class="fw-bold text-dark mb-0">
                <?php echo e(isset($kategoriAktif) ? $kategoriAktif->nama_kategori : 'Kategori Menu'); ?>

            </h4>
            <div class="text-muted small">Warung Rio 1</div>
        </div>

        
        <div class="d-flex flex-nowrap gap-2 overflow-auto pb-3 px-3 custom-scroll">
            
            <a href="<?php echo e(route('pelanggan.index')); ?>"
               class="btn <?php echo e(Request::routeIs('pelanggan.index') ? 'btn-success' : 'btn-outline-success bg-white'); ?> rounded-pill px-4 fw-bold flex-shrink-0 shadow-sm border-success btn-sm-custom">
                <i class="fas fa-utensils me-2"></i>Semua
            </a>

            
            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isActive = request()->segment(count(request()->segments())) == $kategori->id_kategori;
                ?>
                <a href="<?php echo e(route('pelanggan.menu.kategori', $kategori->id_kategori)); ?>"
                   class="btn <?php echo e($isActive ? 'btn-success' : 'btn-outline-success bg-white'); ?> rounded-pill px-4 fw-bold flex-shrink-0 shadow-sm border-success btn-sm-custom">
                    <?php echo e($kategori->nama_kategori); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="px-3 py-3">
        <div class="row g-2 g-md-3"> 
            <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
            <div class="col-6 col-md-4 col-lg-2-4"> 
                <div class="card h-100 border-0 shadow-sm rounded-4 card-menu overflow-hidden">
                    <div class="position-relative">
                        <img src="<?php echo e(asset('assets/gambar/'.$menu->gambar)); ?>"
                             class="card-img-top"
                             alt="<?php echo e($menu->nama_menu); ?>"
                             style="height: 180px; object-fit: cover;"> 
                        <div class="position-absolute top-0 end-0 m-2">
                             <span class="badge bg-success rounded-pill px-2">
                                <i class="fas fa-star me-1"></i>4.5
                             </span>
                        </div>
                    </div>

                    <div class="card-body p-2 d-flex flex-column">
                        <h6 class="fw-bold mb-1 text-dark text-truncate small-title"><?php echo e($menu->nama_menu); ?></h6>
                        <div class="text-success fw-bold mb-2 small">
                            Rp <?php echo e(number_format($menu->harga,0,',','.')); ?>

                        </div>

                        <form action="<?php echo e(route('keranjang.add', $menu->id_menu)); ?>" method="POST" class="mt-auto">
                            <?php echo csrf_field(); ?>
                            <div class="d-flex align-items-center gap-1">
                                <input type="number" name="jumlah" value="1" min="1"
                                       class="form-control form-control-sm border-light bg-light text-center fw-bold rounded-2 px-1"
                                       style="width: 40px; font-size: 0.8rem;">
                                <button type="submit" class="btn btn-success btn-sm flex-grow-1 rounded-2 fw-bold p-1" style="font-size: 0.75rem;">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5">
                <i class="fas fa-utensils fa-3x text-light mb-3"></i>
                <p class="text-muted">Menu belum tersedia.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    /* Mengatur agar layout menempel ke navbar (asumsi navbar tinggi 70px) */
    body {
        padding-top: 0 !important;
    }

    .custom-scroll::-webkit-scrollbar { display: none; }
    .custom-scroll { -ms-overflow-style: none; scrollbar-width: none; }

    /* Ukuran khusus agar di laptop bisa 5 card per baris (opsional) */
    @media (min-width: 1200px) {
        .col-lg-2-4 {
            flex: 0 0 auto;
            width: 20%;
        }
    }

    .card-menu { 
        transition: all 0.2s ease-in-out; 
        border: 1px solid #f1f1f1 !important;
    }
    
    .card-menu:hover { 
        transform: translateY(-3px); 
        box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
    }

    .small-title {
        font-size: 0.9rem;
        line-height: 1.2;
    }

    .btn-sm-custom {
        font-size: 0.85rem;
        padding: 6px 15px;
    }

    /* Hilangkan padding default dari layout utama jika ada */
    main {
        padding: 0 !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\warung_rio1\warung_rio1\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>