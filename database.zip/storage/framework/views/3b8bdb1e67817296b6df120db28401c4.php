

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card shadow border-0">
                <div class="card-header bg-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="card-title mb-0">
                            <i class="fas fa-utensils me-2 text-secondary"></i>Data Menu
                        </h4>
                        <a href="/admin/menu/create" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>Tambah Menu
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if($data->isEmpty()): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-utensils fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">Belum ada menu</h5>
                            <p class="text-muted">Mulai dengan menambahkan menu pertama.</p>
                            <a href="/admin/menu/create" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Tambah Menu Pertama
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th class="border-0">#</th>
                                        <th class="border-0">Gambar</th>
                                        <th class="border-0">Nama Menu</th>
                                        <th class="border-0">Kategori</th>
                                        <th class="border-0">Harga</th>
                                        <th class="border-0">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="fw-bold text-muted"><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <?php if($d->gambar): ?>
                                                <img src="<?php echo e(asset('assets/gambar/'.$d->gambar)); ?>" class="rounded" width="60" height="60" alt="Gambar Menu" style="object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <i class="fas fa-utensils text-primary me-2"></i>
                                                <div>
                                                    <div class="fw-bold"><?php echo e($d->nama_menu); ?></div>
                                                    <?php if($d->deskripsi): ?>
                                                        <small class="text-muted"><?php echo e(Str::limit($d->deskripsi, 50)); ?></small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary"><?php echo e($d->kategori->nama_kategori); ?></span>
                                        </td>
                                        <td class="fw-bold text-success">Rp <?php echo e(number_format($d->harga, 0, ',', '.')); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="/admin/menu/<?php echo e($d->id_menu); ?>/edit" class="btn btn-outline-warning btn-sm">
                                                    <i class="fas fa-edit me-1"></i>Edit
                                                </a>
                                                <form action="/admin/menu/<?php echo e($d->id_menu); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?')">
                                                        <i class="fas fa-trash me-1"></i>Hapus
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3 text-muted">
                            <small>Total: <?php echo e($data->count()); ?> menu</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    border-radius: 10px;
}
.card-header {
    border-radius: 10px 10px 0 0 !important;
    border-bottom: 1px solid #dee2e6;
}
.table th {
    font-weight: 600;
    color: #495057;
}
.btn-group .btn {
    margin-right: 5px;
}
.btn-group .btn:last-child {
    margin-right: 0;
}
.badge {
    font-size: 0.75em;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/admin/menu/index.blade.php ENDPATH**/ ?>