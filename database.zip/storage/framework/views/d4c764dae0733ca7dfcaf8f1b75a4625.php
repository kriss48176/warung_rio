

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-header bg-primary text-white text-center py-4">
                    <h3 class="mb-0">Halaman Pembayaran</h3>
                    <small>Selesaikan pembayaran untuk menyelesaikan pesanan Anda</small>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success mx-4 mt-3"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger mx-4 mt-3"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <div class="card-body p-5">
                    <div class="row">
                        
                        <div class="col-md-6 mb-4">
                            <h5 class="mb-4 text-primary">Informasi Pengiriman</h5>
                            <form action="<?php echo e(route('checkout.store')); ?>" method="POST" id="checkoutForm">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Nama Lengkap</label>
                                    <input type="text" name="nama_pelanggan" class="form-control form-control-lg" placeholder="Masukkan nama lengkap" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Alamat Lengkap</label>
                                    <textarea name="alamat" class="form-control form-control-lg" rows="3" placeholder="Masukkan alamat lengkap pengiriman" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Nomor Telepon</label>
                                    <input type="tel" name="no_hp" class="form-control form-control-lg" placeholder="Contoh: 081234567890" required>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label fw-semibold">Catatan Tambahan (Opsional)</label>
                                    <textarea name="catatan" class="form-control" rows="2" placeholder="Catatan khusus untuk pesanan"></textarea>
                                </div>

                                <h5 class="mb-3 text-primary">Metode Pembayaran</h5>
                                <div class="mb-4">
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="radio" name="metode_pembayaran" id="cash" value="cash" checked>
                                        <label class="form-check-label fw-semibold" for="cash">
                                            <i class="fas fa-money-bill-wave me-2 text-success"></i> Bayar di Tempat (Cash)
                                        </label>
                                        <small class="text-muted d-block ms-4">Bayar langsung saat pesanan sampai</small>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="metode_pembayaran" id="transfer" value="transfer">
                                        <label class="form-check-label fw-semibold" for="transfer">
                                            <i class="fas fa-university me-2 text-primary"></i> Transfer Bank
                                        </label>
                                        <small class="text-muted d-block ms-4">Transfer ke rekening bank kami</small>
                                    </div>
                                </div>

                                
                                <div id="bankDetails" class="d-none">
                                    <div class="card bg-light p-3 mb-4">
                                        <h6 class="text-primary mb-3">Informasi Rekening Bank</h6>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <strong>Bank BCA</strong><br>
                                                No. Rekening: 1234567890<br>
                                                Atas Nama: Rumah Makan Rio 1
                                            </div>
                                            <div class="col-sm-6">
                                                <strong>Bank Mandiri</strong><br>
                                                No. Rekening: 0987654321<br>
                                                Atas Nama: Rumah Makan Rio 1
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-success btn-lg w-100 py-3">
                                    <i class="fas fa-check-circle me-2"></i> Konfirmasi & Buat Pesanan
                                </button>
                            </form>
                        </div>

                        
                        <div class="col-md-6">
                            <div class="sticky-top" style="top: 20px;">
                                <h5 class="mb-4 text-primary text-center">Struk Pesanan</h5>
                                <div class="card border-2 border-primary">
                                    <div class="card-body p-4">
                                        
                                        <div class="text-center mb-4">
                                            <h4 class="text-primary mb-1">Rumah Makan Rio 1</h4>
                                            <p class="text-muted small mb-1">Jl. Raya Contoh No. 123, Kota Malang</p>
                                            <p class="text-muted small">Telp: (0341) 123456 | Email: info@riorestaurant.com</p>
                                            <hr class="my-3">
                                            <div class="row text-center">
                                                <div class="col-6">
                                                    <small class="text-muted">Tanggal</small><br>
                                                    <strong><?php echo e(date('d/m/Y')); ?></strong>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Waktu</small><br>
                                                    <strong><?php echo e(date('H:i')); ?></strong>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="mb-3">
                                            <h6 class="text-primary border-bottom pb-2">Detail Pesanan</h6>
                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                                    <div>
                                                        <strong><?php echo e($item->menu->nama_menu); ?></strong><br>
                                                        <small class="text-muted"><?php echo e($item->jumlah); ?> x Rp <?php echo e(number_format($item->harga,0,',','.')); ?></small>
                                                    </div>
                                                    <div class="text-end">
                                                        <strong>Rp <?php echo e(number_format($item->total_harga,0,',','.')); ?></strong>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        
                                        <div class="border-top pt-3">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <span class="fw-semibold">Subtotal:</span>
                                                <span class="fw-semibold">Rp <?php echo e(number_format($grandTotal,0,',','.')); ?></span>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="h5 text-primary mb-0">Total Pembayaran:</span>
                                                <span class="h5 text-primary mb-0">Rp <?php echo e(number_format($grandTotal,0,',','.')); ?></span>
                                            </div>
                                        </div>

                                        
                                        <div class="text-center mt-4">
                                            <small class="text-muted d-block mb-2">Scan QR Code untuk Pembayaran Cepat</small>
                                            <div class="border p-3 rounded bg-light">
                                                <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=PAYMENT-<?php echo e(time()); ?>-<?php echo e($grandTotal); ?>" alt="QR Code" class="img-fluid" style="max-width: 150px;">
                                                <p class="small text-muted mt-2">Kode Pembayaran: <strong><?php echo e(strtoupper(substr(md5(time()), 0, 8))); ?></strong></p>
                                            </div>
                                        </div>

                                        
                                        <div class="text-center mt-4 pt-3 border-top">
                                            <small class="text-muted">
                                                Terima kasih telah memesan di Rumah Makan Rio 1<br>
                                                Pesanan akan diproses dalam 15-30 menit
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const transferRadio = document.getElementById('transfer');
    const cashRadio = document.getElementById('cash');
    const bankDetails = document.getElementById('bankDetails');

    function toggleBankDetails() {
        if (transferRadio.checked) {
            bankDetails.classList.remove('d-none');
        } else {
            bankDetails.classList.add('d-none');
        }
    }

    transferRadio.addEventListener('change', toggleBankDetails);
    cashRadio.addEventListener('change', toggleBankDetails);
});
</script>


<style>
.card {
    transition: all 0.3s ease;
}
.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
.sticky-top {
    z-index: 100;
}
.form-check-input:checked {
    background-color: #0d6efd;
    border-color: #0d6efd;
}
.btn-success {
    background: linear-gradient(45deg, #28a745, #20c997);
    border: none;
    transition: all 0.3s ease;
}
.btn-success:hover {
    background: linear-gradient(45deg, #218838, #1aa085);
    transform: translateY(-1px);
    box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/pelanggan/checkout.blade.php ENDPATH**/ ?>