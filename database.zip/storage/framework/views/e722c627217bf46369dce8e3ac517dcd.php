

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-3 text-gray-800">
                        <i class="fas fa-credit-card text-primary me-2"></i>
                        Detail Transaksi
                    </h1>
                    <p class="mb-0 text-primary">
                        <i class="fas fa-info-circle me-1"></i>
                        <?php echo e($transaksi->kode_transaksi); ?>

                    </p>
                </div>
                <a href="<?php echo e(route('admin.transaksi.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-2"></i>
                    Kembali
                </a>
            </div>

            <div class="row">
                <div class="col-lg-8">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-info-circle me-2"></i>
                                Informasi Transaksi
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">ID Transaksi</label>
                                        <p><?php echo e($transaksi->id_transaksi); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Kode Transaksi</label>
                                        <p><?php echo e($transaksi->kode_transaksi); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Pelanggan</label>
                                        <p><?php echo e($transaksi->pelanggan->nama ?? 'N/A'); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Metode Pembayaran</label>
                                        <p><?php echo e(ucfirst($transaksi->metode_pembayaran)); ?></p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Total Tagihan</label>
                                        <p class="h5 text-success">Rp <?php echo e(number_format($transaksi->total_tagihan, 0, ',', '.')); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Jumlah Dibayar</label>
                                        <p class="h5 text-info">Rp <?php echo e(number_format($transaksi->jumlah_dibayar ?? 0, 0, ',', '.')); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Status Pembayaran</label>
                                        <span class="badge fs-6 bg-<?php echo e($transaksi->status_pembayaran == 'lunas' ? 'success' : ($transaksi->status_pembayaran == 'pending' ? 'warning' : 'danger')); ?>">
                                            <?php echo e(ucfirst($transaksi->status_pembayaran)); ?>

                                        </span>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Tanggal Dibuat</label>
                                        <p><?php echo e($transaksi->created_at->format('d F Y, H:i')); ?></p>
                                    </div>
                                </div>
                            </div>

                            <?php if($transaksi->catatan): ?>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Catatan</label>
                                    <p><?php echo e($transaksi->catatan); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if($transaksi->bukti_pembayaran): ?>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Bukti Pembayaran</label>
                                    <div>
                                        <img src="<?php echo e(asset('storage/bukti_pembayaran/' . $transaksi->bukti_pembayaran)); ?>" alt="Bukti Pembayaran" class="img-fluid rounded" style="max-width: 300px;">
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Detail Pesanan
                            </h6>
                        </div>
                        <div class="card-body">
                            <?php if($transaksi->pesanan): ?>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">ID Pesanan</label>
                                    <p><?php echo e($transaksi->pesanan->id_pesanan); ?></p>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Status Pesanan</label>
                                    <span class="badge bg-<?php echo e($transaksi->pesanan->status_pesanan == 'Selesai' ? 'success' : ($transaksi->pesanan->status_pesanan == 'Diproses' ? 'warning' : ($transaksi->pesanan->status_pesanan == 'Diantar' ? 'info' : 'secondary'))); ?>">
                                        <?php echo e($transaksi->pesanan->status_pesanan ?? 'Menunggu'); ?>

                                    </span>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Total Pesanan</label>
                                    <p>Rp <?php echo e(number_format($transaksi->pesanan->total_harga ?? 0, 0, ',', '.')); ?></p>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">Data pesanan tidak ditemukan</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/admin/transaksi/show.blade.php ENDPATH**/ ?>