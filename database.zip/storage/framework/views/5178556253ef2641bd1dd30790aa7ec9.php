<?php $__env->startSection('content'); ?>
<div class="py-2" style="background: linear-gradient(135deg, #f0f7f4 0%, #f8fbf9 100%); min-height: 100vh;">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0"><i class="fas fa-history me-2 text-success"></i>Pesanan Saya</h4>
        <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn btn-outline-success btn-sm rounded-pill">
            <i class="fas fa-plus me-1"></i> Pesan Lagi
        </a>
    </div>

    <?php if($statuses->isEmpty()): ?>
        <div class="card border-0 shadow-sm rounded-4 py-5 text-center">
            <div class="card-body">
                <i class="fas fa-receipt fa-4x text-light mb-3"></i>
                <p class="text-muted fs-5">Belum ada riwayat pesanan.</p>
                <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn btn-success px-4">Mulai Belanja</a>
            </div>
        </div>
    <?php else: ?>
        <div class="row g-3">
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12">
                <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                    
                    <div class="card-header bg-white border-bottom py-2 d-flex justify-content-between align-items-center">
                        <span class="small text-muted fw-bold text-uppercase">ID #<?php echo e($status->id); ?></span>
                        <?php
                            $badgeClass = 'bg-warning';
                            $icon = 'fa-clock';
                            if($status->status == 'proses') { $badgeClass = 'bg-primary'; $icon = 'fa-fire'; }
                            if($status->status == 'dikirim') { $badgeClass = 'bg-info'; $icon = 'fa-motorcycle'; }
                            if($status->status == 'selesai') { $badgeClass = 'bg-success'; $icon = 'fa-check-double'; }
                            if($status->status == 'batal') { $badgeClass = 'bg-danger'; $icon = 'fa-times'; }
                        ?>
                        <span class="badge <?php echo e($badgeClass); ?> rounded-pill px-3 py-2">
                            <i class="fas <?php echo e($icon); ?> me-1"></i> <?php echo e(ucfirst($status->status)); ?>

                        </span>
                    </div>

                    <div class="card-body p-3">
                        <div class="row g-3">
                            
                            <div class="col-md-5 border-end-md">
                                <div class="d-flex mb-2">
                                    <i class="fas fa-user text-muted me-3 mt-1" style="width: 15px;"></i>
                                    <div>
                                        <small class="d-block text-muted">Penerima</small>
                                        <span class="fw-bold small"><?php echo e($status->nama_pelanggan); ?></span>
                                    </div>
                                </div>
                                <div class="d-flex mb-2">
                                    <i class="fas fa-map-marker-alt text-muted me-3 mt-1" style="width: 15px;"></i>
                                    <div>
                                        <small class="d-block text-muted">Alamat</small>
                                        <span class="small"><?php echo e(Str::limit($status->alamat, 50)); ?></span>
                                    </div>
                                </div>
                                <div class="d-flex">
                                    <i class="fas fa-credit-card text-muted me-3 mt-1" style="width: 15px;"></i>
                                    <div>
                                        <small class="d-block text-muted">Pembayaran</small>
                                        <span class="badge bg-light text-dark border small"><?php echo e(strtoupper($status->metode_pembayaran)); ?></span>
                                        <?php if($status->metode_pembayaran == 'bank_transfer'): ?>
                                            <div class="mt-2">
                                                <button class="btn btn-sm btn-outline-primary" onclick="toggleUpload(<?php echo e($status->id); ?>)">
                                                    <i class="fas fa-upload me-1"></i> Upload Bukti
                                                </button>
                                            </div>
                                            <div id="uploadForm<?php echo e($status->id); ?>" class="mt-2 d-none">
                                                <form action="<?php echo e(route('checkout.uploadBukti', $status->id)); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="file" name="bukti_pembayaran" class="form-control form-control-sm" accept="image/*" required>
                                                    <button type="submit" class="btn btn-sm btn-success mt-1">Upload</button>
                                                </form>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="col-md-7">
                                <div class="bg-light rounded-3 p-2" style="max-height: 120px; overflow-y: auto;">
                                    <?php $__currentLoopData = $status->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex justify-content-between align-items-center mb-1 pb-1 border-bottom border-white">
                                        <span class="small"><b class="text-success"><?php echo e($item['jumlah']); ?>x</b> <?php echo e($item['nama_menu']); ?></span>
                                        <span class="small fw-bold text-dark">Rp <?php echo e(number_format($item['total_harga'],0,',','.')); ?></span>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mt-2 px-1">
                                    <span class="small text-muted"><?php echo e($status->created_at->format('d M, H:i')); ?></span>
                                    <span class="fw-bold text-success">Total: Rp <?php echo e(number_format($status->total_harga,0,',','.')); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<style>
    /* Styling scrollbar untuk daftar menu */
    .bg-light::-webkit-scrollbar { width: 3px; }
    .bg-light::-webkit-scrollbar-thumb { background: #ccc; border-radius: 10px; }

    .border-end-md {
        border-right: 1px solid #eee;
    }

    @media (max-width: 767.98px) {
        .border-end-md {
            border-right: none;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
        }
    }

    .card { transition: transform 0.2s; }
    .card:hover { transform: translateY(-3px); }
</style>

<script>
function toggleUpload(id) {
    const form = document.getElementById('uploadForm' + id);
    form.classList.toggle('d-none');
}

// Handle form submission with AJAX
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('form[action*="upload-bukti"]').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            submitBtn.disabled = true;
            
            fetch(this.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.success);
                    location.reload();
                } else {
                    alert(data.error || 'Terjadi kesalahan');
                }
            })
            .catch(error => {
                alert('Terjadi kesalahan saat upload');
                console.error(error);
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\warung_rio1\warung_rio1\resources\views/pelanggan/status.blade.php ENDPATH**/ ?>