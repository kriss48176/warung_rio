

<?php $__env->startSection('content'); ?>
<div class="container mt-5">

    <h2 class="mb-4 text-center fw-bold">Selamat Datang di Rumah Makan Rio 1</h2>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success shadow-sm"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger shadow-sm"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <div class="mb-4">
        <h5 class="fw-semibold mb-2">Kategori Menu</h5>
        <div class="d-flex flex-wrap gap-2">
            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('pelanggan.menu.kategori', $kategori->id_kategori)); ?>" 
                   class="btn btn-outline-success btn-sm rounded-pill px-3 py-1 shadow-sm">
                    <?php echo e($kategori->nama_kategori); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="row g-3">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-4 col-lg-3"> 
            <div class="card shadow-sm border-0 rounded-4 menu-card h-100">

                
                <div class="ratio ratio-4x3">
                    <img src="<?php echo e(asset('assets/gambar/'.$menu->gambar)); ?>"
                         class="rounded-top-4 object-fit-cover"
                         alt="<?php echo e($menu->nama_menu); ?>">
                </div>

                <div class="card-body d-flex flex-column p-3">

                    
                    <h6 class="fw-bold text-dark mb-1 text-truncate"><?php echo e($menu->nama_menu); ?></h6>

                    
                    <p class="text-muted small mb-1"><?php echo e($menu->kategori->nama_kategori); ?></p>

                    
                    <p class="fw-bold text-success small mb-2">
                        Rp <?php echo e(number_format($menu->harga,0,',','.')); ?>

                    </p>

                    
                    <p class="text-truncate2 small text-secondary mb-2">
                        <?php echo e($menu->deskripsi); ?>

                    </p>

                    
                    <form action="<?php echo e(route('keranjang.add', $menu->id_menu)); ?>" 
                          method="POST" class="mt-auto">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex gap-2">
                            <input type="number" name="jumlah" value="1" min="1"
                                   class="form-control form-control-sm">
                            <button type="submit" class="btn btn-success btn-sm px-3">
                                Tambah
                            </button>
                        </div>
                    </form>

                    
                    <a href="<?php echo e(route('checkout.index')); ?>"
                       class="btn btn-primary btn-sm w-100 mt-2">
                        Pesan
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($menus->links('pagination::bootstrap-5')); ?>

    </div>
</div>


<style>

    /* Hover card */
    .menu-card {
        transition: transform .2s ease, box-shadow .2s ease;
    }
    .menu-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    }

    /* Truncate deskripsi 2 baris */
    .text-truncate2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    /* Gambar */
    .object-fit-cover {
        object-fit: cover;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>