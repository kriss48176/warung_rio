

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">

            <!-- HEADER -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-3 text-gray-800">
                        <i class="fas fa-tachometer-alt text-primary me-2"></i>
                        Dashboard Admin
                    </h1>
                    <p class="mb-0 text-primary">
                        <i class="fas fa-user me-1"></i>
                        Selamat datang, <?php echo e(session('admin_username')); ?>!
                    </p>
                </div>
                <div class="text-muted">
                    <i class="fas fa-calendar-alt me-1"></i>
                    <?php echo e(date('l, d F Y')); ?>

                </div>
            </div>

            <!-- STATISTICS -->
            <div class="row mb-4">

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Kategori</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\App\Models\Kategori::count()); ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-tags fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Menu</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\App\Models\Menu::count()); ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-utensils fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-info shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Pesanan</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\App\Models\Pesanan::count()); ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-shopping-cart fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-warning shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pesanan Pending</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo e(\App\Models\Pesanan::where('status_pesanan', 'Menunggu')->count()); ?>

                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-clock fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TOTAL TRANSAKSI (NEW) -->
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-dark shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-dark text-uppercase mb-1">Total Transaksi</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php echo e(\App\Models\Transaksi::count()); ?>

                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-credit-card fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- RECENT ORDERS -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-clock me-2"></i> Pesanan Terbaru
                    </h6>
                </div>
                <div class="card-body">

                    <?php if(\App\Models\Pesanan::count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Pelanggan</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = \App\Models\Pesanan::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($p->id_pesanan); ?></td>
                                        <td><?php echo e($p->nama_pelanggan); ?></td>
                                        <td>Rp <?php echo e(number_format($p->total_harga)); ?></td>
                                        <td><?php echo e($p->status_pesanan); ?></td>
                                        <td><?php echo e($p->created_at->format('d/m/Y H:i')); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/admin/pesanan/'.$p->id_pesanan)); ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center">Belum ada pesanan.</p>
                    <?php endif; ?>

                </div>
            </div>

            <!-- RECENT TRANSACTIONS -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-credit-card me-2"></i> Transaksi Terbaru
                    </h6>
                </div>
                <div class="card-body">

                    <?php if(\App\Models\Transaksi::count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Kode Transaksi</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = \App\Models\Transaksi::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($trx->id_transaksi); ?></td>
                                        <td><?php echo e($trx->kode_transaksi); ?></td>
                                        <td>Rp <?php echo e(number_format($trx->total_tagihan)); ?></td>
                                        <td><?php echo e(ucfirst($trx->status_pembayaran)); ?></td>
                                        <td><?php echo e($trx->created_at->format('d/m/Y H:i')); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('transaksi.show', $trx->id_transaksi)); ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center">Belum ada transaksi.</p>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
</div>

<style>
.border-left-primary { border-left: 0.25rem solid #4e73df !important; }
.border-left-success { border-left: 0.25rem solid #1cc88a !important; }
.border-left-info { border-left: 0.25rem solid #36b9cc !important; }
.border-left-warning { border-left: 0.25rem solid #f6c23e !important; }
.border-left-dark { border-left: 0.25rem solid #000 !important; }
.text-gray-800 { color: #5a5c69 !important; }
.shadow { box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15) !important; }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\acer\warung_rio1\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>